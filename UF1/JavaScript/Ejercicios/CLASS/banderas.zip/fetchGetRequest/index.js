const showCountryInfo = json => {
  const content = document.getElementById('content');
  // CLEAR CONTENT
  content.innerHTML = '';

  json.forEach(element => {
    const img = document.createElement('img');
    img.src = element.flag;

    const title = document.createElement('h2');
    title.innerHTML = element.name;

    const container = document.createElement('div');
    container.classList.add('country');
    container.appendChild(title);
    container.appendChild(img);

    content.appendChild(container);
  });
};

const getInfo = () => {
  const value = document.getElementById('input-value').value;
  request(`https://restcountries.eu/rest/v2/name/${value}`, showCountryInfo);
};
