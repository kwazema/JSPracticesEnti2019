const array1 =   ['Harry', 'Ron', 'Hermione', 'Albus', 'Severus', 'Sirius', 'Remus'];
const N = 3;

console.log(array1.slice(0, N));