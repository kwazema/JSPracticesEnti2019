const array1 =  ['Goku', 'Gohan', 'Goten'] ;
const array2 =  ['Vegeta', 'Trunks'];

const arrayFinal = array1.concat(array2);
console.log(arrayFinal);