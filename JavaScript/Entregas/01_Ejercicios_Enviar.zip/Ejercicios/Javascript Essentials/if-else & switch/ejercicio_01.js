const num1 = 5;
const num2 = 10;

if (num1 > num2) {
    console.log(num1);
}else {
    console.log(num2);
}