const num1 = 5;
const num2 = -10;

const result = num1 >= num2 ? "Positivo" : "Negativo"; //expresion ternaria
const result2 = num2 >= num1 ? "Positivo" : "Negativo"; //expresion ternaria

console.log(result);
console.log(result2);
