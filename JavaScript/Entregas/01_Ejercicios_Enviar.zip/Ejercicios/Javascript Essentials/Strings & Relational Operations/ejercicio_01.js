const string1 = 'Goku';
const string2 = 'Gohan';

const result1 = string1 + string2;
console.log(result1);

const result2 = `Bienvenido! ${string1} tu hijo es ${string2}`;
console.log(result2);
