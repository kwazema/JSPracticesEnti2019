const string = 'Goku';

console.log(string[1]);
console.log(string[2]);