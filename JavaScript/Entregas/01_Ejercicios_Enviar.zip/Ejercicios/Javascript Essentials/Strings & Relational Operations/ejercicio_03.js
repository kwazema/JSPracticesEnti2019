const string = 'Andreu';
const string1 = 'Diana';

console.log(string[0] === 'A');

const result = string1[0] === 'A' ? true : false; //expresion ternaria
console.log(result);
