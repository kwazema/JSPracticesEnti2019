var num1 = 5;
var num2 = 10.54;

console.log(num1 % 1);
console.log((num1 % 1) === 0);

console.log(num2 % 1);
console.log((num2 % 1) === 0);