var num1 = 5;
var num2 = 12;

//Se puede hacer un if
console.log((num1 % 2) === 0);
console.log((num2 % 2) === 0);