var base = 5;
var altura = 12;

console.log(base * altura);