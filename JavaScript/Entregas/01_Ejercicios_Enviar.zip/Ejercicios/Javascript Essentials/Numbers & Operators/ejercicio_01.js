var num1 = 5;
var num2 = 12;
console.log(num1 + num2)