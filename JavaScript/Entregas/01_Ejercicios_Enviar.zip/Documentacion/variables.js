// VAR DEPRECATED
var a = 1;
a = 2;
console.log(a);

// LET CAN BE REASSIGNED
let b = 1;
b = 2;
console.log(b);

// CONST CAN'T BE REASSIGNED
const c = 1;
//c = 2; WOULD CRASH
console.log(c);

// let UNDEFINED
let d;
console.log(d);