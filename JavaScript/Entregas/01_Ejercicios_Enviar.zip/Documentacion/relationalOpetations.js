const a = 1;
const b = 1;
const c = "1";
const d = 2;

//== convierte todo en string y compara
//=== compara contenido y string
//el == no se usa solo el ===

console.log(a == b);
console.log(b == c); 
console.log(b === c); 

console.log(b != c); 
console.log(b !== c); 

console.log(a > b);
console.log(a >= b);

console.log(a < b);
console.log(a <= b);

