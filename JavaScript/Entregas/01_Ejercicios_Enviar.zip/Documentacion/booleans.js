const a = true;
const b = false;

console.log(typeof b);