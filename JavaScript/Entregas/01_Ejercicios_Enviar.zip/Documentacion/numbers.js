const integer = 1;
const negative = -5;
const float = 10.5;
const bool = true;
const text = "Hello World"

//typeof -> nos dice el tipo de varibles
console.log(typeof integer); 
console.log(typeof negative);
console.log(typeof float);
console.log(typeof bool);
console.log(typeof text);