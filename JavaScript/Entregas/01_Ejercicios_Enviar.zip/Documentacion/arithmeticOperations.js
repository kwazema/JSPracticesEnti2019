const n1 = 2;
const n2 = 3;

console.log(n1 * n2);
console.log(n1 / n2);
console.log((n1 / n2).toFixed(2));
console.log(n1 + n2);
console.log(n1 - n2);
console.log(n1 % 2);
