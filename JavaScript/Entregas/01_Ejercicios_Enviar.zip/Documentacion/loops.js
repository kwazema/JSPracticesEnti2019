const array = [1, 2, 3];

for (let i = 0; i < array.length; i++) {
    console.log(`Index: ${i} Array: ${array[i]}`);
}

array.forEach(item => { 
    console.log(item);
});

let a = 0;
while (a <= 10) {
    console.log(a);
    a++;
}

do {
    
} while (condition);